package com.spark.android;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class SparkAdminReceiver extends DeviceAdminReceiver {
    private static final String TAG = "SparkAdminReceiver";
    
    @Override
    public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        Log.d(TAG, "Device admin enabled");
    }
    
    @Override
    public void onDisabled(Context context, Intent intent) {
        super.onDisabled(context, intent);
        Log.d(TAG, "Device admin disabled");
    }
    
    @Override
    public void onPasswordFailed(Context context, Intent intent, Intent data) {
        super.onPasswordFailed(context, intent, data);
        Log.d(TAG, "Password failed");
    }
    
    @Override
    public void onPasswordSucceeded(Context context, Intent intent, Intent data) {
        super.onPasswordSucceeded(context, intent, data);
        Log.d(TAG, "Password succeeded");
    }
}