package com.spark.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SparkHttpClient {
    private static final String TAG = "SparkHttpClient";
    private static final int TIMEOUT = 30000; // 30 секунд
    
    private Context context;
    private OkHttpClient client;
    private String baseUrl;
    private String authHeader;
    
    public SparkHttpClient(Context context) {
        this.context = context;
        this.client = new OkHttpClient.Builder()
                .connectTimeout(TIMEOUT, TimeUnit.MILLISECONDS)
                .readTimeout(TIMEOUT, TimeUnit.MILLISECONDS)
                .writeTimeout(TIMEOUT, TimeUnit.MILLISECONDS)
                .build();
        
        SharedPreferences prefs = context.getSharedPreferences("spark_config", Context.MODE_PRIVATE);
        this.baseUrl = prefs.getString("serverUrl", "");
        String username = prefs.getString("username", "");
        String password = prefs.getString("password", "");
        
        // Создаем Basic Auth заголовок
        String credentials = username + ":" + password;
        String auth = Base64.getEncoder().encodeToString(credentials.getBytes());
        this.authHeader = "Basic " + auth;
    }
    
    public boolean registerDevice(DeviceInfo deviceInfo) {
        try {
            JSONObject requestData = new JSONObject();
            requestData.put("id", deviceInfo.id);
            requestData.put("os", deviceInfo.os);
            requestData.put("arch", deviceInfo.arch);
            requestData.put("lan", deviceInfo.lan);
            requestData.put("wan", deviceInfo.wan);
            requestData.put("mac", deviceInfo.mac);
            
            // Добавляем детальную информацию об устройстве
            JSONObject net = new JSONObject();
            net.put("sent", deviceInfo.netSent);
            net.put("recv", deviceInfo.netRecv);
            requestData.put("net", net);
            
            JSONObject cpu = new JSONObject();
            cpu.put("model", deviceInfo.cpuModel);
            cpu.put("usage", deviceInfo.cpuUsage);
            cpu.put("cores", new JSONObject().put("logical", deviceInfo.cpuCores));
            requestData.put("cpu", cpu);
            
            JSONObject ram = new JSONObject();
            ram.put("total", deviceInfo.ramTotal);
            ram.put("used", deviceInfo.ramUsed);
            ram.put("usage", deviceInfo.ramUsage);
            requestData.put("ram", ram);
            
            JSONObject disk = new JSONObject();
            disk.put("total", deviceInfo.diskTotal);
            disk.put("used", deviceInfo.diskUsed);
            disk.put("usage", deviceInfo.diskUsage);
            requestData.put("disk", disk);
            
            requestData.put("uptime", deviceInfo.uptime);
            requestData.put("hostname", deviceInfo.hostname);
            requestData.put("username", deviceInfo.username);
            
            JSONObject response = makeRequest("/device/list", requestData);
            return response != null && response.optInt("code", -1) == 0;
            
        } catch (Exception e) {
            Log.e(TAG, "Error registering device", e);
            return false;
        }
    }
    
    public boolean sendHeartbeat(DeviceInfo deviceInfo) {
        try {
            JSONObject requestData = new JSONObject();
            
            // Отправляем только изменившиеся данные
            if (deviceInfo.cpuUsage >= 0) {
                JSONObject cpu = new JSONObject();
                cpu.put("usage", deviceInfo.cpuUsage);
                requestData.put("cpu", cpu);
            }
            
            if (deviceInfo.netSent >= 0 || deviceInfo.netRecv >= 0) {
                JSONObject net = new JSONObject();
                if (deviceInfo.netSent >= 0) net.put("sent", deviceInfo.netSent);
                if (deviceInfo.netRecv >= 0) net.put("recv", deviceInfo.netRecv);
                requestData.put("net", net);
            }
            
            if (deviceInfo.ramUsed >= 0) {
                JSONObject ram = new JSONObject();
                ram.put("used", deviceInfo.ramUsed);
                ram.put("usage", deviceInfo.ramUsage);
                requestData.put("ram", ram);
            }
            
            if (deviceInfo.diskUsed >= 0) {
                JSONObject disk = new JSONObject();
                disk.put("used", deviceInfo.diskUsed);
                disk.put("usage", deviceInfo.diskUsage);
                requestData.put("disk", disk);
            }
            
            JSONObject response = makeRequest("/device/list", requestData);
            return response != null && response.optInt("code", -1) == 0;
            
        } catch (Exception e) {
            Log.e(TAG, "Error sending heartbeat", e);
            return false;
        }
    }
    
    public JSONObject getCommands() {
        try {
            JSONObject requestData = new JSONObject();
            JSONObject response = makeRequest("/device/list", requestData);
            return response;
        } catch (Exception e) {
            Log.e(TAG, "Error getting commands", e);
            return null;
        }
    }
    
    public JSONObject executeCommand(String action, JSONObject parameters) {
        try {
            JSONObject requestData = new JSONObject();
            requestData.put("device", SparkConfig.DEVICE_ID);
            
            if (parameters != null) {
                for (String key : parameters.keys()) {
                    requestData.put(key, parameters.get(key));
                }
            }
            
            JSONObject response = makeRequest("/device/" + action, requestData);
            return response;
            
        } catch (Exception e) {
            Log.e(TAG, "Error executing command: " + action, e);
            return null;
        }
    }
    
    public byte[] downloadFile(String filePath) {
        try {
            JSONObject requestData = new JSONObject();
            requestData.put("device", SparkConfig.DEVICE_ID);
            requestData.put("files", new org.json.JSONArray().put(filePath));
            
            Request request = new Request.Builder()
                .url(baseUrl + "/api/device/file/get")
                .addHeader("Authorization", authHeader)
                .post(RequestBody.create(MediaType.parse("application/json"), requestData.toString()))
                .build();
            
            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    return response.body().bytes();
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error downloading file: " + filePath, e);
        }
        return null;
    }
    
    public boolean uploadFile(String filePath, byte[] fileData) {
        try {
            File file = new File(filePath);
            RequestBody fileBody = RequestBody.create(MediaType.parse("application/octet-stream"), fileData);
            
            MultipartBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.getName())
                .addFormDataPart("path", file.getParent())
                .addFormDataPart("device", SparkConfig.DEVICE_ID)
                .addPart(fileBody)
                .build();
            
            Request request = new Request.Builder()
                .url(baseUrl + "/api/device/file/upload")
                .addHeader("Authorization", authHeader)
                .post(requestBody)
                .build();
            
            try (Response response = client.newCall(request).execute()) {
                return response.isSuccessful();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error uploading file: " + filePath, e);
            return false;
        }
    }
    
    private JSONObject makeRequest(String endpoint, JSONObject data) throws IOException, JSONException {
        Request request = new Request.Builder()
            .url(baseUrl + "/api" + endpoint)
            .addHeader("Authorization", authHeader)
            .addHeader("Content-Type", "application/json")
            .post(RequestBody.create(MediaType.parse("application/json"), data.toString()))
            .build();
        
        try (Response response = client.newCall(request).execute()) {
            String responseBody = response.body().string();
            
            if (!response.isSuccessful()) {
                Log.e(TAG, "HTTP Error: " + response.code() + " - " + responseBody);
                return null;
            }
            
            return new JSONObject(responseBody);
        }
    }
}