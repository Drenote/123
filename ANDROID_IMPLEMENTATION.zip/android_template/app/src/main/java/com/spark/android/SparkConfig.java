package com.spark.android;

public class SparkConfig {
    // Эти значения будут заполнены при генерации APK
    public static final String SERVER_URL = "http://localhost:8000";
    public static final String USERNAME = "admin";
    public static final String PASSWORD = "password";
    public static final String DEVICE_NAME = "Android Device";
    public static final String DEVICE_ID = "generated-device-id";
    public static final String ARCH = "arm64";
}