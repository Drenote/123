package com.spark.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class SparkHttpClient {
    private static final String TAG = "SparkHttpClient";
    private static final int TIMEOUT = 30000; // 30 секунд
    
    private final OkHttpClient client;
    private final Context context;
    private String baseUrl;
    private String authHeader;
    
    public SparkHttpClient(Context context) {
        this.context = context;
        this.client = new OkHttpClient.Builder()
                .connectTimeout(TIMEOUT, TimeUnit.MILLISECONDS)
                .readTimeout(TIMEOUT, TimeUnit.MILLISECONDS)
                .writeTimeout(TIMEOUT, TimeUnit.MILLISECONDS)
                .build();
        
        // Инициализация конфигурации
        initConfig();
    }
    
    private void initConfig() {
        SharedPreferences prefs = context.getSharedPreferences("spark_config", Context.MODE_PRIVATE);
        baseUrl = SparkConfig.SERVER_URL;
        String credentials = SparkConfig.USERNAME + ":" + SparkConfig.PASSWORD;
        String encoded = Base64.getEncoder().encodeToString(credentials.getBytes());
        authHeader = "Basic " + encoded;
    }
    
    public boolean registerDevice(DeviceInfo deviceInfo) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("id", SparkConfig.DEVICE_ID);
            payload.put("os", "android");
            payload.put("arch", SparkConfig.ARCH);
            payload.put("lan", deviceInfo.lan);
            payload.put("wan", deviceInfo.wan);
            payload.put("mac", deviceInfo.mac);
            
            // CPU info
            JSONObject cpu = new JSONObject();
            cpu.put("model", deviceInfo.cpuModel);
            cpu.put("usage", deviceInfo.cpuUsage);
            cpu.put("cores", new JSONObject()
                    .put("logical", deviceInfo.cpuCoresLogical)
                    .put("physical", deviceInfo.cpuCoresPhysical));
            payload.put("cpu", cpu);
            
            // RAM info
            JSONObject ram = new JSONObject();
            ram.put("total", deviceInfo.ramTotal);
            ram.put("used", deviceInfo.ramUsed);
            ram.put("usage", deviceInfo.ramUsage);
            payload.put("ram", ram);
            
            // Disk info
            JSONObject disk = new JSONObject();
            disk.put("total", deviceInfo.diskTotal);
            disk.put("used", deviceInfo.diskUsed);
            disk.put("usage", deviceInfo.diskUsage);
            payload.put("disk", disk);
            
            // Net info
            JSONObject net = new JSONObject();
            net.put("sent", deviceInfo.netSent);
            net.put("recv", deviceInfo.netRecv);
            payload.put("net", net);
            
            payload.put("uptime", deviceInfo.uptime);
            payload.put("hostname", deviceInfo.hostname);
            payload.put("username", SparkConfig.DEVICE_NAME);
            
            RequestBody body = RequestBody.create(
                MediaType.parse("application/json"), 
                payload.toString()
            );
            
            Request request = new Request.Builder()
                .url(baseUrl + "/api/device/list")
                .addHeader("Authorization", authHeader)
                .post(body)
                .build();
            
            try (Response response = client.newCall(request).execute()) {
                String responseBody = response.body().string();
                JSONObject jsonResponse = new JSONObject(responseBody);
                
                if (jsonResponse.getInt("code") == 0) {
                    Log.d(TAG, "Device registered successfully");
                    return true;
                } else {
                    Log.e(TAG, "Registration failed: " + jsonResponse.getString("msg"));
                    return false;
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error registering device", e);
            return false;
        }
    }
    
    public boolean sendHeartbeat(DeviceInfo deviceInfo) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("device", SparkConfig.DEVICE_ID);
            
            // Частичная информация об устройстве
            JSONObject net = new JSONObject();
            net.put("sent", deviceInfo.netSent);
            net.put("recv", deviceInfo.netRecv);
            payload.put("net", net);
            
            JSONObject cpu = new JSONObject();
            cpu.put("usage", deviceInfo.cpuUsage);
            payload.put("cpu", cpu);
            
            JSONObject ram = new JSONObject();
            ram.put("used", deviceInfo.ramUsed);
            ram.put("usage", deviceInfo.ramUsage);
            payload.put("ram", ram);
            
            payload.put("uptime", deviceInfo.uptime);
            
            RequestBody body = RequestBody.create(
                MediaType.parse("application/json"), 
                payload.toString()
            );
            
            Request request = new Request.Builder()
                .url(baseUrl + "/api/device/list")
                .addHeader("Authorization", authHeader)
                .post(body)
                .build();
            
            try (Response response = client.newCall(request).execute()) {
                return response.isSuccessful();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error sending heartbeat", e);
            return false;
        }
    }
    
    public JSONObject getCommands() {
        try {
            JSONObject payload = new JSONObject();
            payload.put("device", SparkConfig.DEVICE_ID);
            
            RequestBody body = RequestBody.create(
                MediaType.parse("application/json"), 
                payload.toString()
            );
            
            Request request = new Request.Builder()
                .url(baseUrl + "/api/device/list")
                .addHeader("Authorization", authHeader)
                .post(body)
                .build();
            
            try (Response response = client.newCall(request).execute()) {
                String responseBody = response.body().string();
                return new JSONObject(responseBody);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting commands", e);
            return null;
        }
    }
    
    public boolean sendResponse(String commandId, boolean success, String data) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("device", SparkConfig.DEVICE_ID);
            payload.put("command_id", commandId);
            payload.put("success", success);
            payload.put("data", data);
            
            RequestBody body = RequestBody.create(
                MediaType.parse("application/json"), 
                payload.toString()
            );
            
            Request request = new Request.Builder()
                .url(baseUrl + "/api/device/list")
                .addHeader("Authorization", authHeader)
                .post(body)
                .build();
            
            try (Response response = client.newCall(request).execute()) {
                return response.isSuccessful();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error sending response", e);
            return false;
        }
    }
    
    public byte[] downloadFile(String filePath) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("device", SparkConfig.DEVICE_ID);
            payload.put("files", new String[]{filePath});
            
            RequestBody body = RequestBody.create(
                MediaType.parse("application/json"), 
                payload.toString()
            );
            
            Request request = new Request.Builder()
                .url(baseUrl + "/api/device/file/get")
                .addHeader("Authorization", authHeader)
                .post(body)
                .build();
            
            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    return response.body().bytes();
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error downloading file", e);
        }
        return null;
    }
    
    public boolean uploadFile(String filePath, byte[] fileData) {
        try {
            RequestBody fileBody = RequestBody.create(
                MediaType.parse("application/octet-stream"), 
                fileData
            );
            
            String url = baseUrl + "/api/device/file/upload?path=" + 
                        android.net.Uri.encode(filePath) + 
                        "&file=" + android.net.Uri.encode(filePath.substring(filePath.lastIndexOf('/') + 1)) +
                        "&device=" + SparkConfig.DEVICE_ID;
            
            Request request = new Request.Builder()
                .url(url)
                .addHeader("Authorization", authHeader)
                .post(fileBody)
                .build();
            
            try (Response response = client.newCall(request).execute()) {
                return response.isSuccessful();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error uploading file", e);
            return false;
        }
    }
}