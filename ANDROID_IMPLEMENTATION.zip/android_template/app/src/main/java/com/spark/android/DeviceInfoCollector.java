package com.spark.android;

import android.content.Context;
import android.content.pm.ConfigurationInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.Debug;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

public class DeviceInfoCollector {
    private static final String TAG = "DeviceInfoCollector";
    
    private Context context;
    
    public DeviceInfoCollector(Context context) {
        this.context = context;
    }
    
    public DeviceInfo collectDeviceInfo() {
        DeviceInfo info = new DeviceInfo();
        
        try {
            // Основная информация об устройстве
            info.id = SparkConfig.DEVICE_ID;
            info.os = "android";
            info.arch = getArchitecture();
            info.hostname = Build.MODEL;
            info.username = "android";
            
            // Сетевая информация
            info.lan = getLocalIPAddress();
            info.wan = getExternalIPAddress();
            info.mac = getMacAddress();
            
            // Информация о системе
            info.uptime = System.currentTimeMillis() - android.os.SystemClock.elapsedRealtime();
            
            // Детальная информация
            collectSystemInfo(info);
            
        } catch (Exception e) {
            Log.e(TAG, "Error collecting device info", e);
        }
        
        return info;
    }
    
    public DeviceInfo collectPartialInfo() {
        DeviceInfo info = new DeviceInfo();
        
        try {
            // Собираем только изменяющиеся данные для heartbeat
            info.cpuUsage = getCpuUsage();
            info.ramUsed = getUsedMemory();
            info.ramUsage = getMemoryUsage();
            info.diskUsed = getUsedStorage();
            info.diskUsage = getStorageUsage();
            
            // Сетевая статистика
            NetworkStats stats = getNetworkStats();
            info.netSent = stats.sent;
            info.netRecv = stats.received;
            
            info.uptime = System.currentTimeMillis() - android.os.SystemClock.elapsedRealtime();
            
        } catch (Exception e) {
            Log.e(TAG, "Error collecting partial info", e);
        }
        
        return info;
    }
    
    private String getArchitecture() {
        String arch = System.getProperty("os.arch");
        if (arch != null && arch.contains("aarch64")) {
            return "arm64";
        } else if (arch != null && arch.contains("arm")) {
            return "arm";
        } else if (arch != null && arch.contains("x86_64")) {
            return "x86_64";
        } else if (arch != null && arch.contains("x86")) {
            return "x86";
        }
        return "unknown";
    }
    
    private String getLocalIPAddress() {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                for (InetAddress addr : Collections.list(intf.getInetAddresses())) {
                    if (!addr.isLoopbackAddress() && addr.isLinkLocalAddress()) {
                        return addr.getHostAddress();
                    }
                }
            }
        } catch (Exception ex) {
            Log.e(TAG, "Error getting local IP", ex);
        }
        return "0.0.0.0";
    }
    
    private String getExternalIPAddress() {
        // В реальном приложении здесь можно использовать внешний сервис
        // для получения внешнего IP адреса
        return "0.0.0.0";
    }
    
    private String getMacAddress() {
        try {
            WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifiManager != null) {
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                if (wifiInfo != null) {
                    return wifiInfo.getMacAddress();
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting MAC address", e);
        }
        return "00:00:00:00:00:00";
    }
    
    private void collectSystemInfo(DeviceInfo info) throws Exception {
        // CPU информация
        info.cpuModel = Build.HARDWARE;
        info.cpuCores = Runtime.getRuntime().availableProcessors();
        info.cpuUsage = getCpuUsage();
        
        // RAM информация
        info.ramTotal = Runtime.getRuntime().maxMemory();
        info.ramUsed = getUsedMemory();
        info.ramUsage = getMemoryUsage();
        
        // Диск информация
        File internalDir = context.getFilesDir();
        StatFs stat = new StatFs(internalDir.getPath());
        long totalBytes = (long) stat.getBlockCount() * stat.getBlockSize();
        long availableBytes = (long) stat.getAvailableBlocks() * stat.getBlockSize();
        
        info.diskTotal = totalBytes;
        info.diskUsed = totalBytes - availableBytes;
        info.diskUsage = (double) info.diskUsed / totalBytes * 100;
        
        // Сетевая статистика
        NetworkStats stats = getNetworkStats();
        info.netSent = stats.sent;
        info.netRecv = stats.received;
    }
    
    private double getCpuUsage() {
        try {
            // Простое вычисление использования CPU
            long idleBefore = getIdleCpuTime();
            long totalBefore = getTotalCpuTime();
            
            Thread.sleep(1000);
            
            long idleAfter = getIdleCpuTime();
            long totalAfter = getTotalCpuTime();
            
            long idleDiff = idleAfter - idleBefore;
            long totalDiff = totalAfter - totalBefore;
            
            if (totalDiff > 0) {
                return (double) (totalDiff - idleDiff) / totalDiff * 100;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting CPU usage", e);
        }
        return 0.0;
    }
    
    private long getIdleCpuTime() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream("/proc/stat")));
            String line = reader.readLine();
            reader.close();
            
            String[] tokens = line.split(" ");
            return Long.parseLong(tokens[4]); // idle time
        } catch (Exception e) {
            return 0;
        }
    }
    
    private long getTotalCpuTime() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream("/proc/stat")));
            String line = reader.readLine();
            reader.close();
            
            String[] tokens = line.split(" ");
            long total = 0;
            for (int i = 1; i < tokens.length; i++) {
                total += Long.parseLong(tokens[i]);
            }
            return total;
        } catch (Exception e) {
            return 0;
        }
    }
    
    private long getUsedMemory() {
        Runtime runtime = Runtime.getRuntime();
        return runtime.totalMemory() - runtime.freeMemory();
    }
    
    private double getMemoryUsage() {
        Runtime runtime = Runtime.getRuntime();
        long total = runtime.totalMemory();
        long used = total - runtime.freeMemory();
        return (double) used / total * 100;
    }
    
    private long getUsedStorage() {
        File internalDir = context.getFilesDir();
        StatFs stat = new StatFs(internalDir.getPath());
        long totalBytes = (long) stat.getBlockCount() * stat.getBlockSize();
        long availableBytes = (long) stat.getAvailableBlocks() * stat.getBlockSize();
        return totalBytes - availableBytes;
    }
    
    private double getStorageUsage() {
        File internalDir = context.getFilesDir();
        StatFs stat = new StatFs(internalDir.getPath());
        long totalBytes = (long) stat.getBlockCount() * stat.getBlockSize();
        long availableBytes = (long) stat.getAvailableBlocks() * stat.getBlockSize();
        long used = totalBytes - availableBytes;
        return (double) used / totalBytes * 100;
    }
    
    private NetworkStats getNetworkStats() {
        NetworkStats stats = new NetworkStats();
        
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            
            if (activeNetwork != null) {
                // Получаем статистику сетевого трафика
                // Это упрощенная реализация
                stats.sent = 0;
                stats.received = 0;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error getting network stats", e);
        }
        
        return stats;
    }
    
    public static class DeviceInfo {
        public String id;
        public String os;
        public String arch;
        public String lan;
        public String wan;
        public String mac;
        public long netSent;
        public long netRecv;
        public String cpuModel;
        public double cpuUsage;
        public int cpuCores;
        public long ramTotal;
        public long ramUsed;
        public double ramUsage;
        public long diskTotal;
        public long diskUsed;
        public double diskUsage;
        public long uptime;
        public String hostname;
        public String username;
    }
    
    private static class NetworkStats {
        public long sent;
        public long received;
    }
}