# Android API Testing Examples

## Prerequisites

```bash
# Set up environment variables
export SPARK_SERVER="http://localhost:8000"
export USERNAME="admin"
export PASSWORD="password"

# Create authorization header
export AUTH_HEADER="Authorization: Basic $(echo -n "${USERNAME}:${PASSWORD}" | base64)"
```

## Device Registration

### Register Android Device
```bash
curl -X POST "${SPARK_SERVER}/api/device/list" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "id": "android-device-001",
    "os": "android",
    "arch": "arm64-v8a",
    "hostname": "Samsung Galaxy S21",
    "username": "android-user",
    "lan": "192.168.1.100",
    "wan": "203.0.113.1",
    "mac": "00:11:22:33:44:55",
    "net": {
      "sent": 1024000,
      "recv": 2048000
    },
    "cpu": {
      "model": "Exynos 2100",
      "usage": 25.5,
      "cores": {"logical": 8}
    },
    "ram": {
      "total": 8589934592,
      "used": 4294967296,
      "usage": 50.0
    },
    "disk": {
      "total": 128849018880,
      "used": 64424509440,
      "usage": 50.0
    },
    "uptime": 86400,
    "hostname": "SM-G991B",
    "battery": 85,
    "storage_type": "internal",
    "network_type": "wifi",
    "android_version": "13",
    "app_version": "1.0.0"
  }'
```

## Android Commands

### 1. Screenshot

#### Request Screenshot
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/screenshot" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001",
    "parameters": {
      "format": "jpeg",
      "quality": 80
    }
  }'
```

#### Expected Response
```json
{
  "code": 0,
  "msg": "Screenshot command sent to device",
  "data": {
    "device": "android-device-001",
    "action": "screenshot",
    "status": "pending"
  }
}
```

### 2. File Operations

#### List Files
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/file/list" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001",
    "parameters": {
      "path": "/sdcard/"
    }
  }'
```

#### Expected Response
```json
{
  "code": 0,
  "msg": "File list command sent",
  "data": {
    "device": "android-device-001",
    "path": "/sdcard/",
    "files": [
      {
        "name": "Documents",
        "path": "/sdcard/Documents",
        "size": 0,
        "isDirectory": true,
        "modified": 1640995200
      },
      {
        "name": "DCIM",
        "path": "/sdcard/DCIM",
        "size": 0,
        "isDirectory": true,
        "modified": 1640995200
      },
      {
        "name": "download.txt",
        "path": "/sdcard/download.txt",
        "size": 1024,
        "isDirectory": false,
        "modified": 1640995200
      }
    ]
  }
}
```

#### Get Files
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/file/get" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001",
    "parameters": {
      "files": [
        "/sdcard/download.txt",
        "/sdcard/Documents/readme.md"
      ]
    }
  }'
```

#### Remove Files
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/file/remove" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001",
    "parameters": {
      "files": [
        "/sdcard/tempfile.txt"
      ]
    }
  }'
```

#### Upload File
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/file/upload" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001",
    "parameters": {
      "path": "/sdcard/Download/",
      "name": "uploaded_file.txt",
      "data": "base64_encoded_file_content"
    }
  }'
```

### 3. Process Management

#### List Processes
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/process/list" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001"
  }'
```

#### Expected Response
```json
{
  "code": 0,
  "msg": "Process list command sent",
  "data": {
    "device": "android-device-001",
    "processes": [
      {
        "pid": 1234,
        "uid": 10086,
        "name": "com.android.systemui"
      },
      {
        "pid": 5678,
        "uid": 10123,
        "name": "com.android.chrome"
      },
      {
        "pid": 9012,
        "uid": 10234,
        "name": "com.spotify.music"
      }
    ]
  }
}
```

#### Kill Process
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/process/kill" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001",
    "parameters": {
      "pid": 9012
    }
  }'
```

### 4. Device Control

#### Lock Screen
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/lock" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001"
  }'
```

#### Restart Device
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/restart" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001",
    "parameters": {
      "delay": 5
    }
  }'
```

#### Shutdown Device
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/shutdown" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001",
    "parameters": {
      "delay": 10
    }
  }'
```

## Bulk Operations

### Send Multiple Commands
```bash
curl -X POST "${SPARK_SERVER}/api/device/android/bulk" \
  -H "${AUTH_HEADER}" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-001",
    "commands": [
      {
        "action": "screenshot",
        "parameters": {"format": "jpeg"}
      },
      {
        "action": "process/list"
      },
      {
        "action": "file/list",
        "parameters": {"path": "/sdcard/"}
      }
    ]
  }'
```

## Error Responses

### Invalid Device
```json
{
  "code": -1,
  "msg": "Android device not found"
}
```

### Invalid Command
```json
{
  "code": -1,
  "msg": "Unknown Android command: invalid_action"
}
```

### Missing Parameters
```json
{
  "code": -1,
  "msg": "No files specified"
}
```

### Permission Denied
```json
{
  "code": -1,
  "msg": "Admin rights required for device lock"
}
```

## Testing Script

Create a test script to automate API testing:

```bash
#!/bin/bash

# android_test.sh - Android API Testing Script

SPARK_SERVER="http://localhost:8000"
USERNAME="admin"
PASSWORD="password"
DEVICE_ID="android-device-001"

echo "Testing Android API endpoints..."

# Test device registration
echo "1. Testing device registration..."
curl -s -X POST "${SPARK_SERVER}/api/device/list" \
  -H "Authorization: Basic $(echo -n "${USERNAME}:${PASSWORD}" | base64)" \
  -H "Content-Type: application/json" \
  -d '{"id": "'${DEVICE_ID}'", "os": "android"}' | jq .

# Test screenshot
echo -e "\n2. Testing screenshot command..."
curl -s -X POST "${SPARK_SERVER}/api/device/android/screenshot" \
  -H "Authorization: Basic $(echo -n "${USERNAME}:${PASSWORD}" | base64)" \
  -H "Content-Type: application/json" \
  -d '{"device": "'${DEVICE_ID}'"}' | jq .

# Test file list
echo -e "\n3. Testing file list..."
curl -s -X POST "${SPARK_SERVER}/api/device/android/file/list" \
  -H "Authorization: Basic $(echo -n "${USERNAME}:${PASSWORD}" | base64)" \
  -H "Content-Type: application/json" \
  -d '{"device": "'${DEVICE_ID}'", "parameters": {"path": "/sdcard/"}}' | jq .

# Test process list
echo -e "\n4. Testing process list..."
curl -s -X POST "${SPARK_SERVER}/api/device/android/process/list" \
  -H "Authorization: Basic $(echo -n "${USERNAME}:${PASSWORD}" | base64)" \
  -H "Content-Type: application/json" \
  -d '{"device": "'${DEVICE_ID}'"}' | jq .

echo -e "\nAndroid API testing completed!"
```

## Notes

1. **Authentication**: All requests require Basic Auth with valid credentials
2. **Device ID**: Must be a valid registered Android device ID
3. **Permissions**: Some commands require admin rights on the Android device
4. **Rate Limiting**: Implement appropriate rate limiting for production use
5. **Security**: Use HTTPS in production environments
6. **File Size**: Large file operations may require chunked upload/download