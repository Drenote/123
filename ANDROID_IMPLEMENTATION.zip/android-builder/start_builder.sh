#!/bin/bash

# Скрипт для запуска Android Builder API
# Требует: Python 3.8+, Android SDK

echo "Запуск Android Builder API..."

# Проверяем Python
if ! command -v python3 &> /dev/null; then
    echo "Python 3 не найден. Установите Python 3.8+"
    exit 1
fi

# Проверяем Android SDK
if [ -z "$ANDROID_HOME" ]; then
    echo "ANDROID_HOME не установлен. Установите Android SDK"
    echo "Инструкции: https://developer.android.com/studio"
    exit 1
fi

# Проверяем наличие Android SDK компонентов
if [ ! -d "$ANDROID_HOME/platforms" ]; then
    echo "Android SDK platforms не найдены. Установите Android API 26+"
    exit 1
fi

if [ ! -d "$ANDROID_HOME/build-tools" ]; then
    echo "Android SDK build-tools не найдены. Установите Android Build Tools"
    exit 1
fi

# Устанавливаем Python зависимости
echo "Установка Python зависимостей..."
pip3 install -r requirements.txt

# Запускаем API
echo "Запуск API сервера на порту 8080..."
python3 android_builder_api.py