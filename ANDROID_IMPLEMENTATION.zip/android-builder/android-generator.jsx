import React, { useState } from 'react';
import { Modal, Form, Input, Button, Select, message, Progress, Upload, Space, Alert } from 'antd';
import { UploadOutlined, DownloadOutlined } from '@ant-design/icons';
import i18n from "../web/src/locale/locale";

const { Option } = Select;

function AndroidGenerator(props) {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [apkUrl, setApkUrl] = useState(null);

  const archOptions = [
    { value: 'arm64-v8a', label: 'ARM64' },
    { value: 'armeabi-v7a', label: 'ARM' },
    { value: 'x86_64', label: 'x86_64' }
  ];

  const onFinish = async (values) => {
    setLoading(true);
    setProgress(0);
    
    try {
      // Валидация URL
      const url = new URL(values.serverUrl);
      
      // Симуляция процесса сборки APK
      await simulateBuild(values, setProgress);
      
      // В реальной реализации здесь будет вызов API для генерации APK
      const generatedApk = await generateAndroidAPK(values);
      setApkUrl(generatedApk.downloadUrl);
      
      message.success('APK успешно создан!');
    } catch (error) {
      message.error(`Ошибка при создании APK: ${error.message}`);
    } finally {
      setLoading(false);
      setProgress(0);
    }
  };

  const simulateBuild = async (values, setProgress) => {
    const steps = [
      'Подготовка окружения...',
      'Компиляция Android проекта...',
      'Встраивание конфигурации...',
      'Сборка APK...',
      'Подписание APK...',
      'Завершение...'
    ];

    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setProgress(((i + 1) / steps.length) * 100);
    }
  };

  const generateAndroidAPK = async (config) => {
    // Симуляция генерации APK
    // В реальной реализации здесь будет:
    // 1. Создание Android проекта с вшитыми настройками
    // 2. Компиляция с помощью gradlew
    // 3. Подписание APK
    
    const response = await fetch('/api/android/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(config)
    });

    if (!response.ok) {
      throw new Error('Ошибка сервера при генерации APK');
    }

    return await response.json();
  };

  const downloadAPK = () => {
    if (apkUrl) {
      const link = document.createElement('a');
      link.href = apkUrl;
      link.download = `spark-android-${Date.now()}.apk`;
      link.click();
    }
  };

  return (
    <Modal
      title="Генератор Android APK"
      open={props.open}
      onCancel={props.onCancel}
      footer={null}
      width={600}
    >
      <Form
        form={form}
        layout="vertical"
        onFinish={onFinish}
        initialValues={{
          serverUrl: location.origin,
          deviceName: 'Android Device',
          arch: 'arm64-v8a'
        }}
      >
        <Form.Item
          label="URL сервера Spark"
          name="serverUrl"
          rules={[
            { required: true, message: 'Введите URL сервера' },
            { 
              pattern: /^https?:\/\/.+/, 
              message: 'Введите корректный URL (http:// или https://)' 
            }
          ]}
        >
          <Input placeholder="http://192.168.1.100:8000" />
        </Form.Item>

        <Space style={{ width: '100%' }}>
          <Form.Item
            label="Имя пользователя"
            name="username"
            rules={[{ required: true, message: 'Введите имя пользователя' }]}
            style={{ flex: 1 }}
          >
            <Input placeholder="admin" />
          </Form.Item>

          <Form.Item
            label="Пароль"
            name="password"
            rules={[{ required: true, message: 'Введите пароль' }]}
            style={{ flex: 1 }}
          >
            <Input.Password placeholder="••••••••" />
          </Form.Item>
        </Space>

        <Space style={{ width: '100%' }}>
          <Form.Item
            label="Имя устройства"
            name="deviceName"
            rules={[{ required: true, message: 'Введите имя устройства' }]}
            style={{ flex: 1 }}
          >
            <Input placeholder="Android Device" />
          </Form.Item>

          <Form.Item
            label="Архитектура"
            name="arch"
            rules={[{ required: true, message: 'Выберите архитектуру' }]}
            style={{ flex: 1 }}
          >
            <Select placeholder="Выберите архитектуру">
              {archOptions.map(option => (
                <Option key={option.value} value={option.value}>
                  {option.label}
                </Option>
              ))}
            </Select>
          </Form.Item>
        </Space>

        <Alert
          message="Информация"
          description="Сгенерированный APK будет содержать вшитые настройки подключения к серверу. После установки приложение автоматически зарегистрируется на сервере."
          type="info"
          style={{ marginBottom: 16 }}
        />

        {loading && (
          <div style={{ marginBottom: 16 }}>
            <Progress percent={progress} status="active" />
            <p style={{ textAlign: 'center', marginTop: 8 }}>
              Создание APK... {Math.round(progress)}%
            </p>
          </div>
        )}

        <Form.Item>
          <Space>
            <Button 
              type="primary" 
              htmlType="submit" 
              loading={loading}
              disabled={loading}
            >
              {loading ? 'Создание...' : 'Создать APK'}
            </Button>
            
            {apkUrl && (
              <Button 
                type="primary" 
                icon={<DownloadOutlined />}
                onClick={downloadAPK}
              >
                Скачать APK
              </Button>
            )}
            
            <Button onClick={props.onCancel}>
              Отмена
            </Button>
          </Space>
        </Form.Item>
      </Form>
    </Modal>
  );
}

export default AndroidGenerator;